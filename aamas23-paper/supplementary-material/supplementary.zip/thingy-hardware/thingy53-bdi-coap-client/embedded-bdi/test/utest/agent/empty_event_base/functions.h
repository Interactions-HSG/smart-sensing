#ifndef UTEST_AGENT_EMPTY_EVENT_BASE_FUNCTIONS_H_
#define UTEST_AGENT_EMPTY_EVENT_BASE_FUNCTIONS_H_

bool action_event_base_settings_do_nothing ()
{
  return true;
}

#endif /* UTEST_AGENT_EMPTY_EVENT_BASE_FUNCTIONS_H_ */