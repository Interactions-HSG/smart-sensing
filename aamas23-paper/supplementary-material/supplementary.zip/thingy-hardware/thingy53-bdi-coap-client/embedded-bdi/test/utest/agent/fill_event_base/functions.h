#ifndef UTEST_AGENT_FILL_EVENT_BASE_FUNCTIONS_H_
#define UTEST_AGENT_FILL_EVENT_BASE_FUNCTIONS_H_

bool action_fill_event_base_do_nothing()
{
  return true;
}

bool update_belief_belief_1_do_nothing_fill_event_base_config(bool var)
{
  return !var;
}

bool update_belief_belief_2_do_nothing_fill_event_base_config(bool var)
{
  return !var;
}

bool update_belief_belief_3_do_nothing_fill_event_base_config(bool var)
{
  return !var;
}

bool update_belief_belief_4_do_nothing_fill_event_base_config(bool var)
{
  return !var;
}

bool update_belief_belief_5_do_nothing_fill_event_base_config(bool var)
{
  return !var;
}

bool update_belief_belief_6_do_nothing_fill_event_base_config(bool var)
{
  return !var;
}

bool update_belief_belief_7_do_nothing_fill_event_base_config(bool var)
{
  return !var;
}

bool update_belief_belief_8_do_nothing_fill_event_base_config(bool var)
{
  return !var;
}

#endif /* UTEST_AGENT_FILL_EVENT_BASE_FUNCTIONS_H_ */