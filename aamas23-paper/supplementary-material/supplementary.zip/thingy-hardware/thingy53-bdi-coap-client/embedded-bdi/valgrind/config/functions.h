/*
 * functions.h
 *
 *  Created on: Sep 24, 2020
 *      Author: Matuzalem Muller
 */

#ifndef CONFIG_FUNCTIONS_H_
#define CONFIG_FUNCTIONS_H_


bool update_belief_1(bool var)
{
  return !var;
}

bool update_belief_2(bool var)
{
  return !var;
}

bool update_belief_3(bool var)
{
  return !var;
}
bool update_belief_4(bool var)
{
  return !var;
}

bool update_belief_5(bool var)
{
  return !var;
}

bool action_action_1()
{
  return true;
}

bool action_action_2()
{
  return true;
}

bool action_action_3()
{
  return true;
}

bool action_action_4()
{
  return true;
}

bool action_action_5()
{
  return true;
}

bool action_action_6()
{
  return true;
}

bool action_action_7()
{
  return true;
}

#endif /* CONFIG_FUNCTIONS_H_ */
