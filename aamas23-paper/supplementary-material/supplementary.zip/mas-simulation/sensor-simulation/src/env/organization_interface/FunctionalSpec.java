package organization_interface;

public class FunctionalSpec {
    public int hasQuantityKind;
    public int measurementInterval;
    public int updateInterval;
    public int measurementDuration;
}
