package organization_interface;

import java.util.List;

public class GroupRoleInfos{
    public List<GroupRoleInfo> elements;
    public int num_elements;
}