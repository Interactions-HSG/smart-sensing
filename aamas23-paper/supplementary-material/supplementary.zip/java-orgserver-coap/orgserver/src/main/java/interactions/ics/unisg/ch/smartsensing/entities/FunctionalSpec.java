package interactions.ics.unisg.ch.smartsensing.entities;

public class FunctionalSpec {
    public int hasQuantityKind;
    public int measurementInterval;
    public int updateInterval;
    public int measurementDuration;
}
