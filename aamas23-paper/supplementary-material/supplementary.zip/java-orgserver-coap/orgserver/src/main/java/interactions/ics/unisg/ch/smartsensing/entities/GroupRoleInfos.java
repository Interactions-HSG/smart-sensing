package interactions.ics.unisg.ch.smartsensing.entities;

import java.util.List;

public class GroupRoleInfos{
    public List<GroupRoleInfo> elements;
    public int num_elements;
}